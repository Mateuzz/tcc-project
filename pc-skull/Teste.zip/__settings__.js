window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1893233.json";
window.CONTEXT_OPTIONS = {
    'antialias': false,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
window.SCRIPTS = [ 156138390, 156138901 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: false
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
];
